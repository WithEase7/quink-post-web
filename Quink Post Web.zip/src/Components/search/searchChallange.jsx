import React from 'react'
import Challengepost from "../challengepost";

function SearchChallange() {
    return (
        <div>
           <Challengepost /> 
           <Challengepost /> 
           <Challengepost /> 
           <Challengepost /> 
        </div>
    )
}

export default SearchChallange
