import React from 'react'
import Communitypost from '../communitypost'

function SearchCommunity() {
    return (
        <div>
            <Communitypost />
            <Communitypost />
            <Communitypost />
            <Communitypost />
            <Communitypost />
            <Communitypost />
            <Communitypost />
        </div>
    )
}

export default SearchCommunity
