import React from "react";
import Post from "../post";
import "../../Styles/searchstyle/searchArticle.css";

function SearchArticle() {
  return (
    <div className="searchArticle-Container">
      <Post />
    </div>
  );
}

export default SearchArticle;
