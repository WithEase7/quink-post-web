// const BACKEND = "http://localhost:5000"


const BACKEND="https://quinkpostbackend.herokuapp.com"
export default BACKEND
