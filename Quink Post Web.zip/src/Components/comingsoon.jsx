import React from 'react'
import "../Styles/comingsoon.css"

function Comingsoon() {
    return (
        <div className="coming-soon">
            This Feature will be soon Available.
        </div>
    )
}

export default Comingsoon
