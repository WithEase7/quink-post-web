import React from 'react'
import Comingsoon from './comingsoon'
import Navbar from './navbar'

function Magzinepage() {
    return (
        <div>
            <Navbar />
            <Comingsoon />
        </div>
    )
}

export default Magzinepage
