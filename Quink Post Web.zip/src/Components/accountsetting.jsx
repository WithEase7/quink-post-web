import React from 'react'

function AccountSetting() {
    return(
        <>
            <div>
                
            </div>
        </>
    )
}

export default AccountSetting;